import 'package:flutter/material.dart';

const String google_api_key = "AIzaSyB9pjbcBXWw75JJKKYmBUUpqjJ7F2VaUis";
const Color primaryColor = Colors.deepPurple;
const double defaultPadding = 16;
